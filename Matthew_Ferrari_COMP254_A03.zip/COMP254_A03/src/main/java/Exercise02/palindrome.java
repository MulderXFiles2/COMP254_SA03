package Exercise02;

/*
Exercise 2

Write a short recursive Java method that determines if a string s is a palindrome, that is, it is equal to its reverse.
Examples of palindromes include 'racecar' and 'gohangasalamiimalasagnahog'. Test the method by asking the user to
provide string entries to be checked. Hint: Check the equality of the first and last characters and recur (but be
careful to return the correct value for both odd and even-length strings).

Explaination

If its an odd lettered word, then indexes will be equal
if its an even lettered word, then left side with pass right side, so >=

charAt() takes an int index and returns the character at that index.

Input : racecar

IsAPalindrome("racecar", 0, 6)
IsAPalindrome("racecar", 1, 5)
IsAPalindrome("racecar", 2, 4)
IsAPalindrome("racecar", 3, 3)

Because this is a boolean method, it wants to return true. The base case returns true, then that can satisfy the other
pending methods in the call stack.
ie; IsAPalindrome("racecar", 2, 4) is waiting on aPalindrome("racecar", 3, 3) to be true, then if its true, then
proceed all the way up the stack.

 */

import java.util.Scanner;
//For Input.

public class palindrome {


    public static boolean IsAPalindrome(String a, int lside, int rside) {

        if (lside >= rside){

            return true;
            //This is the base case
        }

        if (a.charAt(lside) != a.charAt(rside)){

            return false;
        }

        return IsAPalindrome(a, lside +1, rside-1);

    }



    public static void main (String[] args){

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter string to check if this is a palindrome: ");

        String input = scanner.nextLine();

        boolean ans = IsAPalindrome(input, 0, input.length() - 1);

        //Strings are indexed, so a.length() -1 gets the last element in the string.

        if (ans) {

            System.out.println(input +  " is a palindrome.");

        } else {

            System.out.println(input + " isn't a palindrome.");
        }

    }
}


