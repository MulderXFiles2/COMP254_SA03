package exercise3;

import java.io.File;
//this is needed for java to read files and folders on the system.
import java.util.Scanner;

/*
Exercise 3

Implement a recursive method with calling signature find(path, filename) that reports all entries of the file system
rooted at the given path having the given file name. Test the method with a real path, filename from your file system.
Hint: Review use of the java.io.File class and the week 5 examples.

Explanation

root is the root path of the file, and name is the name of the file.

the isFile() checks if the root is a file or a folder. returns false if its a folder.

Then root.getName() gets the last name of the root directory, ie; C:\Centennial\Schedule\text.txt returns text.txt
so if it equals the string filename you passed in ie; test.txt,
it will use getAbsolutePath() to get the full path of the variable root.

The first if statement checks if the root directory is a file, and the nested if checks again to make sure if its equal
to the file name being searched for.

else, isDirectory()  (meaning folder), need to loop though all the directories until you find files.

When the root directory is has the method list() invoked on it, it returns all the files and folders in that directory.

so, for every element in (files and other folders) for that root directory,

Make a new file object, and pass into it the directory, and element

root.list() fetches the names of files and folders in a directory.
So if a folder contained other folders and files, it would return the names of those and put it in a list.
ie; Schedule folder had text.txt, home.ini and Assignment folder,
it would return [text.txt, home.ini, Assignment]



The File object comes from java.io.file and  behaves this way: new File(File parent, String child)
so the parent is the root directory, and the child is the current thing.
ie; root could be C:\Centennial, and the next thing is the directory Schedule

The find method passes in the obj (the new File obj that contains the root directory and the element, that changes)
The find method then will recursively call itself till it finds the file.

If it hits another folder, the new folder name is assigned to FileObj, and that is passed as the new root, with the
file we are trying to find. The else if will engage, and then it loops through the new folder and everything in it.

 */

public class FindPath {

    public static void find (File root, String name){

        if (root.isFile()) {

            if(root.getName().equals(name)){
                System.out.println("Found " + root.getAbsolutePath());
            }

        } else if (root.isDirectory()){

            for (String element : root.list()){

                File FileObj = new File(root, element);

                find(FileObj, name);
            }
        }
    }

    public static void main(String[] args) {

        String filepath;
        String filename;

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter folder path to search: ");
        filepath = scanner.nextLine();

        System.out.print("Enter file name to search (ie; file.txt): ");
        filename = scanner.nextLine();

        find(new File(filepath), filename);


    }

}

/*
C:\Centennial\Schedule
test.txt
 */
