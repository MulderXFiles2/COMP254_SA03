package Exercise1;


/*

Exercise 1

Create a recursive algorithm to compute the product of two positive integers, m and n, using only addition and
subtraction. Implement the Java or Python code. Hint: You need subtraction to count down from m or n and addition
to do the arithmetic needed to get the right answer. Check linearSum method from Week 5 examples.

From Slides,
Linear Sum was this method:

if n == 0 then
    return 0
else
    return linearSum(A, n - 1) + A[n - 1]

Take this array: int[]A = {1,2,3,4,5}

linearSum(A,5)

would return linearSum(A,4) + A[4], this means: linearSum(A,4) + 5
This function calls itself, this time, with linearSum(A,4), it cant finish the addition, because it doesnt know the
value of linearSum(A,4). so now, linearSum(A,4) returns linearSum(A,3) + A[3], which is 4.

so, To summarize,
Start LinearSum(A,5), returns,
linearSum(A,4) + 5
LinearSum(A,3) + 4
LinearSum(A,2) + 3
LinearSum(A,1) + 2
LinearSum(A,0) + 1
LinearSum(A,0) then returns 0, since n==0,
it is the base case, since it returns 0, and doesnt call itself anymore.
so now, RECURSIVELY,
LinearSum(A,1) = 0+1 = 1
LinearSum(A,2) = 1+2 = 3
LinearSum(A,3) = 3+3 = 6
LinearSum(A,4) = 6 + 4 = 10
LinearSum(A,5) = 10 + 5 = 15



 */
public class Recursive01 {

    public static int productOfIntegers (int m, int n){
       if (m ==0){
           return 0;
       } else {

            return productOfIntegers(m -1, n) + n;
       }

    }

    //Testing
    public static void main(String[] args) {
        int m = 4;
        int n = 7;
        int result = productOfIntegers(m, n);
        System.out.println(m + " * " + n + " = " + result);
    }

}

/*

productOfIntegers(4,7)
returns
productOfIntegers(3,7) + 7
returns
productOfIntegers(2,7) + 7
returns
productOfIntegers(1,7) + 7
returns
productOfIntegers(0,7) + 7
productOfIntegers(0,7) is base case, so returns 0 so
productOfIntegers(1,7) = 0 + 7
productOfIntegers(2,7) = 7 + 7 = 14
productOfIntegers(3,7) = 14 + 7 = 21
productOfIntegers(4,7) = 21 + 7 = 28

To summarize, This program takes 2 integers, and we want to get the product, but though recursive methods.
This program takes m, calls itself m -1, then adds whatever n is m times. This results in adding n , m times,
which is the same as m*n.

 */
